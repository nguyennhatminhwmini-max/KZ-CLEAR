# KZ CLEAD

**KZ CLEAD** is a lightweight Windows 10/11 desktop utility built with Python and CustomTkinter. It uses a scan-first workflow and avoids deleting personal files by default.

**KZ CLEAD** là công cụ desktop gọn nhẹ cho Windows 10/11, dùng Python và CustomTkinter. Ứng dụng ưu tiên quét trước, không mặc định xóa dữ liệu cá nhân.

## Features / Tính năng

- Dark UI with Vietnamese/English language toggle.
- Scan user and Windows temporary folders; files are **unchecked by default**.
- Select individual results, select all, then confirm before deletion.
- View large files in Downloads, Videos and Desktop (read-only scan).
- View startup entries from common Run registry keys and Startup folders (read-only); opens Windows Startup Apps settings for changes.
- Read-only disk information and a best-effort physical-drive health status via Windows PowerShell/CIM.
- Export a local HTML report.
- No telemetry, account, network service, or automatic background cleanup.

## Safety notes / Lưu ý an toàn

- Review each selected path before deleting. Files in use or protected by Windows may not be removed.
- The temporary-file scan is limited to the current user's TEMP folder and `C:\\Windows\\Temp`.
- Large-file scan is **report-only**; it never offers to delete those files.
- Startup entries are **read-only** in KZ CLEAD. Use Windows Settings to manage them.
- SSD health information depends on the drive, firmware, drivers, and Windows storage provider. `Healthy` is not a guarantee that a drive cannot fail; `Unknown` does not necessarily mean a fault.
- Run as Administrator only if you understand why it is needed. Standard user mode is enough for most scans.
- This is an early release. Back up important data and test on non-critical files first.

## Requirements / Yêu cầu

- Windows 10/11, Python 3.10 or newer (64-bit recommended)
- Internet only for installing dependencies; the app itself does not require internet.
- 8 GB RAM is sufficient; the app is designed for modest PCs.

## Run from source / Chạy từ mã nguồn

Open Command Prompt in this folder:

```bat
py -m venv .venv
.venv\\Scripts\\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

If `py` is not recognized, install Python from https://www.python.org/downloads/windows/ and enable **Add Python to PATH**.

## Build an EXE / Đóng gói EXE

```bat
.venv\\Scripts\\activate
pip install -r requirements-dev.txt
pyinstaller --noconfirm --clean --windowed --name "KZ CLEAD" --collect-all customtkinter main.py
```

The executable will be in `dist\\KZ CLEAD\\KZ CLEAD.exe`. This is an onedir build, which is generally easier to troubleshoot than a one-file build.

## Publish on GitHub / Đăng lên GitHub

1. Create a new repository named `KZ-CLEAD` on GitHub.
2. Do not initialize it with another README if you already have this project.
3. Install Git for Windows if needed.
4. In this folder, run:

```bat
git init
git add .
git commit -m "Initial KZ CLEAD release"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/KZ-CLEAD.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Never publish passwords, tokens, private logs, or personal reports.

To publish a release, build the EXE, test it, then create a GitHub Release and attach the contents of `dist\\KZ CLEAD\\`.

## Project structure / Cấu trúc dự án

```text
KZ_CLEAD/
├── main.py
├── requirements.txt
├── requirements-dev.txt
├── build.bat
├── LICENSE
├── README.md
└── kz_clead/
    ├── __init__.py
    ├── app.py
    ├── scanner.py
    ├── system_info.py
    └── report.py
```

## Disclaimer

KZ CLEAD is an independent community project and is not affiliated with Microsoft. No cleaning utility can guarantee that every candidate file is safe to remove. The user must review and confirm cleanup actions.
