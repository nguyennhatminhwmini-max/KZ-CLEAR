@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Create the virtual environment first:
  echo py -m venv .venv
  echo .venv\Scripts\python -m pip install -r requirements-dev.txt
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --name "KZ CLEAD" --collect-all customtkinter main.py
if errorlevel 1 (
  echo Build failed. Read the error above.
) else (
  echo Build complete: dist\KZ CLEAD\KZ CLEAD.exe
)
pause
