from __future__ import annotations

import html
import json
from datetime import datetime
from pathlib import Path
from typing import Any

def save_html_report(path: str, data: dict[str, Any]) -> None:
    safe_json = json.dumps(data, ensure_ascii=False, indent=2)
    escaped_json = html.escape(safe_json)
    created = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    page = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>KZ CLEAD report</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;background:#111827;color:#e5e7eb;margin:2rem;line-height:1.5}}
main{{max-width:1000px;margin:auto}}h1{{color:#60a5fa}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#1f2937;padding:1rem;border-radius:10px}}
small{{color:#9ca3af}}
</style></head><body><main><h1>KZ CLEAD — System report</h1>
<small>Generated locally: {html.escape(created)}. Review this report before sharing; it may contain file paths, device names, and startup commands.</small>
<pre>{escaped_json}</pre></main></body></html>"""
    Path(path).write_text(page, encoding="utf-8")
