from __future__ import annotations

import os
import sys
import threading
import webbrowser
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk

from . import __version__
from .scanner import ScanItem, scan_temp_files, scan_large_personal_files, delete_temp_item
from .system_info import (
    disk_summary, format_bytes, physical_drive_health, startup_entries, system_summary
)
from .report import save_html_report

TEXT = {
    "vi": {
        "subtitle": "Dọn dẹp Windows có kiểm soát",
        "dashboard": "Tổng quan", "temp": "Quét file tạm", "large": "File lớn", "startup": "Khởi động", "health": "Sức khỏe ổ đĩa",
        "scan_temp": "Quét file tạm", "scan_large": "Tìm file lớn (chỉ đọc)", "refresh": "Làm mới thông tin",
        "clean_selected": "Xóa file đã chọn", "select_all": "Chọn tất cả", "clear_selection": "Bỏ chọn",
        "export": "Xuất báo cáo HTML", "open_startup": "Mở cài đặt ứng dụng khởi động",
        "warning": "An toàn: kết quả quét file tạm không được chọn sẵn. File lớn chỉ để xem, không thể xóa từ màn hình này.",
        "drive": "Ổ hệ thống", "total": "Tổng", "used": "Đã dùng", "free": "Còn trống", "status": "Trạng thái",
        "ready": "Sẵn sàng", "scanning": "Đang quét…", "scan_done": "Quét xong", "no_items": "Không tìm thấy mục phù hợp.",
        "path": "Đường dẫn", "size": "Dung lượng", "category": "Danh mục", "choose": "Chọn", "name": "Tên", "scope": "Phạm vi", "command": "Lệnh/đường dẫn",
        "confirm_title": "Xác nhận xóa", "confirm": "Bạn sắp xóa {n} file tạm (tổng {size}). Không thể hoàn tác. Tiếp tục?",
        "done_title": "Hoàn tất", "done": "Đã xóa {ok} file. Thất bại/bỏ qua: {fail}.",
        "error": "Lỗi", "scan_error": "Không thể quét: ", "report_saved": "Đã lưu báo cáo tại:\n",
        "health_note": "Thông tin sức khỏe phụ thuộc driver/firmware. 'Unknown' không đồng nghĩa ổ đĩa bị hỏng.",
        "no_health": "Windows không cung cấp được dữ liệu sức khỏe ổ đĩa.", "large_note": "Chỉ quét Downloads, Videos, Desktop; không xóa file ở đây.",
        "startup_note": "Danh sách chỉ đọc. Dùng Settings của Windows để bật/tắt mục khởi động.",
        "empty": "Chưa có kết quả. Hãy chạy quét.", "language": "Ngôn ngữ", "admin": "Quyền quản trị", "yes": "Có", "no": "Không",
        "about": "KZ CLEAD v{version} · Không gửi dữ liệu ra ngoài.", "open_report": "Mở báo cáo sau khi lưu",
    },
    "en": {
        "subtitle": "Controlled Windows cleanup",
        "dashboard": "Overview", "temp": "Temp scan", "large": "Large files", "startup": "Startup", "health": "Drive health",
        "scan_temp": "Scan temporary files", "scan_large": "Find large files (read-only)", "refresh": "Refresh system info",
        "clean_selected": "Delete selected files", "select_all": "Select all", "clear_selection": "Clear selection",
        "export": "Export HTML report", "open_startup": "Open Startup Apps settings",
        "warning": "Safety: temp scan results are unchecked by default. Large-file results are informational and cannot be deleted here.",
        "drive": "System drive", "total": "Total", "used": "Used", "free": "Free", "status": "Status",
        "ready": "Ready", "scanning": "Scanning…", "scan_done": "Scan complete", "no_items": "No matching items found.",
        "path": "Path", "size": "Size", "category": "Category", "choose": "Select", "name": "Name", "scope": "Scope", "command": "Command/path",
        "confirm_title": "Confirm deletion", "confirm": "You are about to delete {n} temporary files ({size}). This cannot be undone. Continue?",
        "done_title": "Finished", "done": "Deleted {ok} files. Failed/skipped: {fail}.",
        "error": "Error", "scan_error": "Could not scan: ", "report_saved": "Report saved to:\n",
        "health_note": "Drive health data depends on driver/firmware. 'Unknown' does not mean the drive is faulty.",
        "no_health": "Windows did not provide drive-health information.", "large_note": "Scans Downloads, Videos and Desktop only; files cannot be deleted here.",
        "startup_note": "Read-only list. Use Windows Settings to enable/disable startup items.",
        "empty": "No results yet. Start a scan.", "language": "Language", "admin": "Administrator", "yes": "Yes", "no": "No",
        "about": "KZ CLEAD v{version} · No data is sent externally.", "open_report": "Open report after saving",
    }
}

def main() -> None:
    if sys.platform != "win32":
        print("KZ CLEAD currently supports Windows 10/11 only.")
        return
    App().mainloop()

class App(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.lang = "vi"
        self.items: list[ScanItem] = []
        self.large_items: list[ScanItem] = []
        self.temp_vars: list[tuple[ScanItem, ctk.BooleanVar]] = []
        self.startups: list[dict[str, str]] = []
        self.health: dict = {}
        self.disk: dict = {}
        self.system: dict = {}
        self.current_page = "dashboard"

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.title("KZ CLEAD")
        self.geometry("1120x740")
        self.minsize(900, 600)
        self.configure(fg_color="#0b1120")

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_sidebar()
        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.grid(row=0, column=1, sticky="nsew", padx=(0, 20), pady=20)
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(1, weight=1)
        self.header = ctk.CTkFrame(self.content, fg_color="transparent")
        self.header.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        self.header.grid_columnconfigure(0, weight=1)
        self.page_title = ctk.CTkLabel(self.header, text="", font=ctk.CTkFont(size=25, weight="bold"))
        self.page_title.grid(row=0, column=0, sticky="w")
        self.lang_menu = ctk.CTkSegmentedButton(self.header, values=["VI", "EN"], command=self._set_language, width=110)
        self.lang_menu.set("VI")
        self.lang_menu.grid(row=0, column=1, sticky="e")
        self.body = ctk.CTkFrame(self.content, corner_radius=16, fg_color="#111827")
        self.body.grid(row=1, column=0, sticky="nsew")
        self.body.grid_columnconfigure(0, weight=1)
        self.body.grid_rowconfigure(0, weight=1)
        self.status_label = ctk.CTkLabel(self.content, text="", anchor="w", text_color="#9ca3af")
        self.status_label.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        self._refresh_info()
        self.show_page("dashboard")

    def t(self, key: str, **kwargs) -> str:
        return TEXT[self.lang].get(key, key).format(**kwargs)

    def _build_sidebar(self) -> None:
        self.sidebar = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color="#080d18")
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        ctk.CTkLabel(self.sidebar, text="KZ CLEAD", font=ctk.CTkFont(size=25, weight="bold"), text_color="#60a5fa").pack(anchor="w", padx=20, pady=(25, 0))
        self.subtitle_label = ctk.CTkLabel(self.sidebar, text="", text_color="#9ca3af", wraplength=175, justify="left")
        self.subtitle_label.pack(anchor="w", padx=20, pady=(3, 22))
        self.nav_buttons = {}
        for key, icon in [("dashboard", "◈"), ("temp", "⌁"), ("large", "▤"), ("startup", "↗"), ("health", "♥")]:
            b = ctk.CTkButton(self.sidebar, text=f"{icon}  {key}", anchor="w", height=42, corner_radius=9,
                              fg_color="transparent", hover_color="#1f2937", command=lambda k=key: self.show_page(k))
            b.pack(fill="x", padx=12, pady=3)
            self.nav_buttons[key] = b
        self.sidebar_footer = ctk.CTkLabel(self.sidebar, text="", text_color="#6b7280", wraplength=180, justify="left")
        self.sidebar_footer.pack(side="bottom", anchor="w", padx=18, pady=18)

    def _set_language(self, value: str) -> None:
        self.lang = "vi" if value == "VI" else "en"
        for widget in self.sidebar.winfo_children():
            if isinstance(widget, ctk.CTkButton):
                widget.destroy()
        self.subtitle_label.configure(text=self.t("subtitle"))
        self.sidebar_footer.configure(text=self.t("about", version=__version__))
        for key, icon in [("dashboard", "◈"), ("temp", "⌁"), ("large", "▤"), ("startup", "↗"), ("health", "♥")]:
            b = ctk.CTkButton(self.sidebar, text=f"{icon}  {self.t(key)}", anchor="w", height=42, corner_radius=9,
                              fg_color="#172554" if self.current_page == key else "transparent",
                              hover_color="#1f2937", command=lambda k=key: self.show_page(k))
            # Keep navigation above the footer; pack order is sufficient for this small sidebar.
            b.pack(fill="x", padx=12, pady=3, before=self.sidebar_footer)
            self.nav_buttons[key] = b
        self.show_page(self.current_page)

    def _refresh_info(self) -> None:
        try:
            self.disk = disk_summary()
            self.system = system_summary()
        except Exception as exc:
            self._set_status(f"{self.t('error')}: {exc}")

    def _clear_body(self) -> None:
        for child in self.body.winfo_children():
            child.destroy()

    def _set_status(self, message: str) -> None:
        self.status_label.configure(text=message)

    def show_page(self, page: str) -> None:
        self.current_page = page
        self._clear_body()
        self.page_title.configure(text=self.t(page))
        for key, button in self.nav_buttons.items():
            button.configure(text=f"{ {'dashboard':'◈','temp':'⌁','large':'▤','startup':'↗','health':'♥'}[key] }  {self.t(key)}",
                             fg_color="#172554" if page == key else "transparent")
        if page == "dashboard":
            self._page_dashboard()
        elif page == "temp":
            self._page_temp()
        elif page == "large":
            self._page_large()
        elif page == "startup":
            self._page_startup()
        elif page == "health":
            self._page_health()
        self._set_status(self.t("ready"))

    def _card(self, parent, title: str, value: str, sub: str = ""):
        card = ctk.CTkFrame(parent, corner_radius=14, fg_color="#1f2937")
        ctk.CTkLabel(card, text=title, text_color="#9ca3af").pack(anchor="w", padx=16, pady=(14, 4))
        ctk.CTkLabel(card, text=value, font=ctk.CTkFont(size=23, weight="bold")).pack(anchor="w", padx=16)
        if sub:
            ctk.CTkLabel(card, text=sub, text_color="#9ca3af", wraplength=230, justify="left").pack(anchor="w", padx=16, pady=(4, 14))
        else:
            ctk.CTkLabel(card, text=" ").pack(pady=(0, 8))
        return card

    def _page_dashboard(self) -> None:
        outer = ctk.CTkFrame(self.body, fg_color="transparent")
        outer.pack(fill="both", expand=True, padx=20, pady=20)
        outer.grid_columnconfigure((0, 1, 2), weight=1)
        d = self.disk
        self._card(outer, self.t("drive"), d.get("drive", "C:"), self.system.get("windows", "Windows")).grid(row=0, column=0, sticky="ew", padx=(0, 8), pady=(0, 12))
        self._card(outer, self.t("free"), format_bytes(d.get("free", 0)), f"{100-d.get('percent_used',0):.1f}% free").grid(row=0, column=1, sticky="ew", padx=8, pady=(0, 12))
        self._card(outer, self.t("used"), format_bytes(d.get("used", 0)), f"{d.get('percent_used',0):.1f}% used").grid(row=0, column=2, sticky="ew", padx=(8, 0), pady=(0, 12))
        bar = ctk.CTkProgressBar(outer, height=14, progress_color="#3b82f6")
        bar.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(0, 20))
        bar.set(d.get("percent_used", 0) / 100)
        note = ctk.CTkTextbox(outer, height=150, fg_color="#0f172a", text_color="#cbd5e1", wrap="word")
        note.grid(row=2, column=0, columnspan=3, sticky="nsew")
        note.insert("1.0", self.t("warning") + "\n\n" + self.t("about", version=__version__) + "\n\n" +
                    f"{self.t('admin')}: {self.t('yes') if self.system.get('is_admin') else self.t('no')}")
        note.configure(state="disabled")
        row = ctk.CTkFrame(outer, fg_color="transparent")
        row.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(14, 0))
        ctk.CTkButton(row, text=self.t("scan_temp"), command=lambda: self.show_page("temp")).pack(side="left", padx=(0, 8))
        ctk.CTkButton(row, text=self.t("refresh"), command=self._refresh_dashboard).pack(side="left")

    def _refresh_dashboard(self) -> None:
        self._refresh_info()
        self.show_page("dashboard")

    def _page_temp(self) -> None:
        top = ctk.CTkFrame(self.body, fg_color="transparent")
        top.pack(fill="x", padx=18, pady=(18, 8))
        ctk.CTkLabel(top, text=self.t("warning"), text_color="#fbbf24", wraplength=760, justify="left").pack(anchor="w", pady=(0, 10))
        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x")
        ctk.CTkButton(row, text=self.t("scan_temp"), command=self._scan_temp).pack(side="left", padx=(0, 8))
        ctk.CTkButton(row, text=self.t("select_all"), command=lambda: self._set_all_temp(True), fg_color="#374151").pack(side="left", padx=4)
        ctk.CTkButton(row, text=self.t("clear_selection"), command=lambda: self._set_all_temp(False), fg_color="#374151").pack(side="left", padx=4)
        ctk.CTkButton(row, text=self.t("clean_selected"), command=self._clean_selected, fg_color="#b91c1c", hover_color="#991b1b").pack(side="right")
        self.temp_summary = ctk.CTkLabel(self.body, text=self.t("empty"), anchor="w")
        self.temp_summary.pack(fill="x", padx=20, pady=(0, 6))
        self.temp_list = ctk.CTkScrollableFrame(self.body, fg_color="#0f172a", corner_radius=10)
        self.temp_list.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        self.temp_list.grid_columnconfigure(1, weight=1)
        if self.items:
            self._render_temp_items()

    def _scan_temp(self) -> None:
        self._set_status(self.t("scanning"))
        self.update_idletasks()
        def worker():
            try:
                results = scan_temp_files()
                self.after(0, lambda: self._temp_scan_done(results))
            except Exception as exc:
                self.after(0, lambda: messagebox.showerror(self.t("error"), self.t("scan_error") + str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def _temp_scan_done(self, results: list[ScanItem]) -> None:
        self.items = results
        self.temp_vars = []
        if self.current_page == "temp":
            self._render_temp_items()
        total = sum(x.size for x in results)
        self._set_status(f"{self.t('scan_done')}: {len(results)} files · {format_bytes(total)}")

    def _render_temp_items(self) -> None:
        for child in self.temp_list.winfo_children():
            child.destroy()
        self.temp_vars = []
        total = sum(x.size for x in self.items)
        self.temp_summary.configure(text=f"{len(self.items)} files · {format_bytes(total)} · " + self.t("empty") if not self.items else f"{len(self.items)} files · {format_bytes(total)}")
        if not self.items:
            ctk.CTkLabel(self.temp_list, text=self.t("no_items")).grid(row=0, column=0, padx=12, pady=16, sticky="w")
            return
        ctk.CTkLabel(self.temp_list, text=self.t("choose"), text_color="#9ca3af").grid(row=0, column=0, sticky="w", padx=8, pady=7)
        ctk.CTkLabel(self.temp_list, text=self.t("path"), text_color="#9ca3af").grid(row=0, column=1, sticky="w", padx=8, pady=7)
        ctk.CTkLabel(self.temp_list, text=self.t("size"), text_color="#9ca3af").grid(row=0, column=2, sticky="e", padx=8, pady=7)
        for idx, item in enumerate(self.items, start=1):
            var = ctk.BooleanVar(value=False)
            self.temp_vars.append((item, var))
            ctk.CTkCheckBox(self.temp_list, text="", variable=var, width=25).grid(row=idx, column=0, padx=8, pady=4)
            ctk.CTkLabel(self.temp_list, text=item.path, anchor="w", justify="left", wraplength=650).grid(row=idx, column=1, sticky="ew", padx=8, pady=4)
            ctk.CTkLabel(self.temp_list, text=format_bytes(item.size), anchor="e").grid(row=idx, column=2, sticky="e", padx=8, pady=4)

    def _set_all_temp(self, value: bool) -> None:
        for _, var in self.temp_vars:
            var.set(value)

    def _clean_selected(self) -> None:
        selected = [item for item, var in self.temp_vars if var.get()]
        if not selected:
            messagebox.showinfo("KZ CLEAD", self.t("no_items"))
            return
        total = sum(x.size for x in selected)
        if not messagebox.askyesno(self.t("confirm_title"), self.t("confirm", n=len(selected), size=format_bytes(total))):
            return
        ok = fail = 0
        for item in selected:
            success, _ = delete_temp_item(item)
            if success:
                ok += 1
            else:
                fail += 1
        self.items = [x for x in self.items if Path(x.path).exists()]
        self._render_temp_items()
        self._refresh_info()
        messagebox.showinfo(self.t("done_title"), self.t("done", ok=ok, fail=fail))
        self._set_status(self.t("done", ok=ok, fail=fail))

    def _page_large(self) -> None:
        top = ctk.CTkFrame(self.body, fg_color="transparent")
        top.pack(fill="x", padx=18, pady=18)
        ctk.CTkLabel(top, text=self.t("large_note"), text_color="#fbbf24", wraplength=760, justify="left").pack(anchor="w", pady=(0, 10))
        ctk.CTkButton(top, text=self.t("scan_large"), command=self._scan_large).pack(anchor="w")
        self.large_list = ctk.CTkScrollableFrame(self.body, fg_color="#0f172a", corner_radius=10)
        self.large_list.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        if self.large_items:
            self._render_large()

    def _scan_large(self) -> None:
        self._set_status(self.t("scanning"))
        def worker():
            try:
                results = scan_large_personal_files()
                self.after(0, lambda: self._large_done(results))
            except Exception as exc:
                self.after(0, lambda: messagebox.showerror(self.t("error"), self.t("scan_error") + str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def _large_done(self, results: list[ScanItem]) -> None:
        self.large_items = results
        if self.current_page == "large":
            self._render_large()
        self._set_status(f"{self.t('scan_done')}: {len(results)}")

    def _render_large(self) -> None:
        for child in self.large_list.winfo_children():
            child.destroy()
        ctk.CTkLabel(self.large_list, text=f"{self.t('path')} — {self.t('size')}", anchor="w").pack(fill="x", padx=10, pady=8)
        if not self.large_items:
            ctk.CTkLabel(self.large_list, text=self.t("no_items")).pack(anchor="w", padx=10, pady=8)
        for item in self.large_items:
            ctk.CTkLabel(self.large_list, text=f"{format_bytes(item.size):>10}   {item.path}", anchor="w", justify="left", wraplength=780).pack(fill="x", padx=10, pady=5)

    def _page_startup(self) -> None:
        top = ctk.CTkFrame(self.body, fg_color="transparent")
        top.pack(fill="x", padx=18, pady=18)
        ctk.CTkLabel(top, text=self.t("startup_note"), text_color="#fbbf24", wraplength=760, justify="left").pack(anchor="w", pady=(0, 10))
        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x")
        ctk.CTkButton(row, text=self.t("refresh"), command=self._load_startups).pack(side="left", padx=(0, 8))
        ctk.CTkButton(row, text=self.t("open_startup"), command=self._open_startup_settings).pack(side="left")
        self.startup_list = ctk.CTkScrollableFrame(self.body, fg_color="#0f172a", corner_radius=10)
        self.startup_list.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        if not self.startups:
            self._load_startups()
        else:
            self._render_startups()

    def _load_startups(self) -> None:
        self.startups = startup_entries()
        self._render_startups()

    def _render_startups(self) -> None:
        for child in self.startup_list.winfo_children():
            child.destroy()
        if not self.startups:
            ctk.CTkLabel(self.startup_list, text=self.t("no_items")).pack(anchor="w", padx=10, pady=8)
            return
        for item in self.startups:
            frame = ctk.CTkFrame(self.startup_list, fg_color="#1f2937", corner_radius=8)
            frame.pack(fill="x", padx=6, pady=5)
            ctk.CTkLabel(frame, text=item["name"], font=ctk.CTkFont(weight="bold"), anchor="w").pack(fill="x", padx=10, pady=(8, 2))
            ctk.CTkLabel(frame, text=f'{item["scope"]} · {item["command"]}', text_color="#9ca3af", anchor="w", justify="left", wraplength=780).pack(fill="x", padx=10, pady=(0, 8))

    def _open_startup_settings(self) -> None:
        try:
            os.startfile("ms-settings:startupapps")
        except Exception:
            webbrowser.open("ms-settings:startupapps")

    def _page_health(self) -> None:
        outer = ctk.CTkFrame(self.body, fg_color="transparent")
        outer.pack(fill="both", expand=True, padx=20, pady=20)
        ctk.CTkLabel(outer, text=self.t("health_note"), text_color="#fbbf24", wraplength=800, justify="left").pack(anchor="w", pady=(0, 14))
        ctk.CTkButton(outer, text=self.t("refresh"), command=self._load_health).pack(anchor="w", pady=(0, 12))
        self.health_box = ctk.CTkTextbox(outer, wrap="word", fg_color="#0f172a")
        self.health_box.pack(fill="both", expand=True)
        self._render_health()

    def _load_health(self) -> None:
        self._set_status(self.t("scanning"))
        def worker():
            result = physical_drive_health()
            self.after(0, lambda: self._health_done(result))
        threading.Thread(target=worker, daemon=True).start()

    def _health_done(self, result: dict) -> None:
        self.health = result
        if self.current_page == "health":
            self._render_health()
        self._set_status(self.t("scan_done"))

    def _render_health(self) -> None:
        self.health_box.configure(state="normal")
        self.health_box.delete("1.0", "end")
        if not self.health:
            self.health_box.insert("1.0", self.t("scanning"))
        elif self.health.get("disks"):
            for disk in self.health["disks"]:
                self.health_box.insert("end",
                    f'Name: {disk["name"]}\nMedia: {disk["media_type"]}\nHealth: {disk["health"]}\n'
                    f'Operational status: {disk["operational_status"]}\nCapacity: {format_bytes(disk["size"])}\n\n')
        else:
            self.health_box.insert("1.0", self.health.get("details", self.t("no_health")))
        self.health_box.configure(state="disabled")

    def _build_report_data(self) -> dict:
        return {
            "app": "KZ CLEAD",
            "version": __version__,
            "generated_at": datetime.now().astimezone().isoformat(),
            "system": self.system or system_summary(),
            "disk": self.disk or disk_summary(),
            "drive_health": self.health or {"status": "Not scanned"},
            "startup_entries": self.startups,
            "temporary_scan": [
                {"path": x.path, "size_bytes": x.size, "category": x.category}
                for x in self.items
            ],
            "large_files_report_only": [
                {"path": x.path, "size_bytes": x.size}
                for x in self.large_items
            ],
            "note": "Review before sharing; report can contain local paths and startup commands."
        }

    def _export_report(self) -> None:
        path = filedialog.asksaveasfilename(
            title=self.t("export"), defaultextension=".html",
            filetypes=[("HTML report", "*.html")],
            initialfile=f"KZ_CLEAD_Report_{datetime.now():%Y%m%d_%H%M%S}.html"
        )
        if not path:
            return
        try:
            save_html_report(path, self._build_report_data())
            messagebox.showinfo(self.t("done_title"), self.t("report_saved") + path)
            if messagebox.askyesno(self.t("open_report"), self.t("open_report")):
                webbrowser.open(Path(path).resolve().as_uri())
        except Exception as exc:
            messagebox.showerror(self.t("error"), str(exc))

# Add a persistent report button after App methods are defined by attaching it to the header.
_original_init = App.__init__
def _init_with_report(self):
    _original_init(self)
    self.report_button = ctk.CTkButton(self.header, text=self.t("export"), command=self._export_report, width=180)
    self.report_button.grid(row=0, column=2, padx=(10, 0))
    self.header.grid_columnconfigure(2, weight=0)
App.__init__ = _init_with_report
