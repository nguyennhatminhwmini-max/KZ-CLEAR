"""KZ CLEAD: scan-first Windows cleanup utility."""
__version__ = "0.1.0"
