from __future__ import annotations

import os
from pathlib import Path
from dataclasses import dataclass
from typing import Iterable

@dataclass
class ScanItem:
    path: str
    size: int
    category: str
    safe_root: str

def _is_inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError, RuntimeError):
        return False

def _walk_files(root: Path) -> Iterable[Path]:
    if not root.exists() or not root.is_dir():
        return
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        # Do not descend into symlink/junction-like directories.
        current_path = Path(current)
        dirs[:] = [d for d in dirs if not (current_path / d).is_symlink()]
        for name in files:
            p = current_path / name
            try:
                if p.is_symlink() or not p.is_file():
                    continue
                yield p
            except OSError:
                continue

def temp_roots() -> list[tuple[Path, str]]:
    roots: list[tuple[Path, str]] = []
    user_temp = os.environ.get("TEMP") or os.environ.get("TMP")
    if user_temp:
        roots.append((Path(user_temp), "User temporary files"))
    windows_temp = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Temp"
    if all(str(p).casefold() != str(windows_temp).casefold() for p, _ in roots):
        roots.append((windows_temp, "Windows temporary files"))
    return roots

def scan_temp_files() -> list[ScanItem]:
    results: list[ScanItem] = []
    seen: set[str] = set()
    for root, category in temp_roots():
        if not root.exists():
            continue
        for path in _walk_files(root):
            try:
                resolved = path.resolve()
                key = str(resolved).casefold()
                if key in seen or not _is_inside(resolved, root):
                    continue
                seen.add(key)
                results.append(ScanItem(str(resolved), resolved.stat().st_size, category, str(root.resolve())))
            except (OSError, RuntimeError):
                continue
    results.sort(key=lambda x: x.size, reverse=True)
    return results

def scan_large_personal_files(min_size: int = 512 * 1024 * 1024) -> list[ScanItem]:
    """Read-only scan: results are informational and must never be sent to cleanup."""
    home = Path.home()
    candidates = [home / "Downloads", home / "Videos", home / "Desktop"]
    results: list[ScanItem] = []
    seen: set[str] = set()
    for root in candidates:
        if not root.exists():
            continue
        for path in _walk_files(root):
            try:
                resolved = path.resolve()
                key = str(resolved).casefold()
                if key in seen or not _is_inside(resolved, root):
                    continue
                size = resolved.stat().st_size
                if size >= min_size:
                    seen.add(key)
                    results.append(ScanItem(str(resolved), size, "Large personal file (report only)", str(root.resolve())))
            except (OSError, RuntimeError):
                continue
    results.sort(key=lambda x: x.size, reverse=True)
    return results

def delete_temp_item(item: ScanItem) -> tuple[bool, str]:
    """Delete one file only if it remains inside its originally approved temp root."""
    try:
        path = Path(item.path)
        root = Path(item.safe_root)
        if path.is_symlink() or not path.is_file():
            return False, "Not a regular file or no longer exists"
        if not _is_inside(path, root):
            return False, "Safety check failed: path is outside the approved temporary folder"
        # Re-check the current path and root immediately before deletion.
        resolved = path.resolve(strict=True)
        if not _is_inside(resolved, root):
            return False, "Safety check failed after resolving path"
        resolved.unlink()
        return True, "Deleted"
    except PermissionError:
        return False, "Access denied; try later or run with appropriate permission"
    except OSError as exc:
        return False, str(exc)
