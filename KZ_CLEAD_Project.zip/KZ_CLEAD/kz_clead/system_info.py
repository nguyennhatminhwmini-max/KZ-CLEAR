from __future__ import annotations

import json
import os
import platform
import subprocess
import shutil
import winreg
from pathlib import Path
from typing import Any

def format_bytes(value: int | float) -> str:
    amount = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if amount < 1024 or unit == "TB":
            return f"{amount:.1f} {unit}" if unit != "B" else f"{int(amount)} B"
        amount /= 1024
    return f"{amount:.1f} TB"

def disk_summary() -> dict[str, Any]:
    usage = shutil.disk_usage(os.environ.get("SystemDrive", "C:") + "\\")
    return {
        "drive": os.environ.get("SystemDrive", "C:"),
        "total": usage.total,
        "used": usage.used,
        "free": usage.free,
        "percent_used": round(usage.used / usage.total * 100, 1) if usage.total else 0,
    }

def _run_powershell(script: str, timeout: int = 12) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "RemoteSigned", "-Command", script],
            capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
        if proc.returncode == 0:
            return True, proc.stdout.strip()
        return False, (proc.stderr or proc.stdout).strip()
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, str(exc)

def physical_drive_health() -> dict[str, Any]:
    # Best-effort Windows storage provider information. No writes are performed.
    script = r"""
$ErrorActionPreference = 'Stop'
Get-PhysicalDisk | Select-Object FriendlyName, MediaType, HealthStatus, OperationalStatus, Size |
  ConvertTo-Json -Compress
"""
    ok, output = _run_powershell(script)
    if not ok:
        return {"status": "Unknown", "details": output or "Physical disk health is not available from this Windows storage provider."}
    try:
        data = json.loads(output) if output else []
        if isinstance(data, dict):
            data = [data]
        disks = []
        for d in data:
            disks.append({
                "name": str(d.get("FriendlyName", "Unknown")),
                "media_type": str(d.get("MediaType", "Unknown")),
                "health": str(d.get("HealthStatus", "Unknown")),
                "operational_status": str(d.get("OperationalStatus", "Unknown")),
                "size": int(d.get("Size") or 0),
            })
        return {"status": "Available", "disks": disks}
    except (ValueError, TypeError):
        return {"status": "Unknown", "details": "Windows returned an unrecognized response.", "raw": output}

def startup_entries() -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    locations = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", "Current user"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run", "All users"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "All users (32-bit)"),
    ]
    for hive, subkey, scope in locations:
        try:
            with winreg.OpenKey(hive, subkey, 0, winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as key:
                index = 0
                while True:
                    try:
                        name, value, _ = winreg.EnumValue(key, index)
                        entries.append({"name": str(name), "command": str(value), "scope": scope, "source": subkey})
                        index += 1
                    except OSError:
                        break
        except OSError:
            pass
    startup_dirs = [
        (Path(os.environ.get("APPDATA", "")) / r"Microsoft\Windows\Start Menu\Programs\Startup", "Current user Startup folder"),
        (Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / r"Microsoft\Windows\Start Menu\Programs\Startup", "All users Startup folder"),
    ]
    for folder, scope in startup_dirs:
        try:
            if folder.is_dir():
                for p in folder.iterdir():
                    entries.append({"name": p.name, "command": str(p), "scope": scope, "source": str(folder)})
        except OSError:
            pass
    return entries

def system_summary() -> dict[str, Any]:
    return {
        "computer": platform.node(),
        "windows": platform.platform(),
        "python": platform.python_version(),
        "is_admin": _is_admin(),
    }

def _is_admin() -> bool:
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False
